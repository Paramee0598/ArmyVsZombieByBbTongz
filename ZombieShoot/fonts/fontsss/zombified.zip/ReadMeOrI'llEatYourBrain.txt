ZOMBIFIED
True Type Font by Chad Savage
savagevision@hotmail.com

Freeware: Please distribute this text file with the font.
Font hand-drawn, scanned into PhotoShop, filtered, then Fontified with CorelDRAW 5 - yes, it can be done, but BOY, is it tedious!

Witness the Sinister Visions of Chad Savage at http://www.gothic.net/~savage/ for more free fonts, icons, and stuff.